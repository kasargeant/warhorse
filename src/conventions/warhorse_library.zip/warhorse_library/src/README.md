# README - Module Convention

## ABOUT

## INSTALLATION

    npm install

## USAGE

## DOCUMENTATION

## LICENSE INFORMATION
 
 Please see LICENSE.txt included in this distribution.
 

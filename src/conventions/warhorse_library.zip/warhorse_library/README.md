# Warhorse Project Convention: Library

## ABOUT

This is the default README.md file a Warhorse Project Convention.
Customise this default generated file for your project!

## INSTALLATION

    npm install

## USAGE

## DOCUMENTATION

API documentation can be found in ./docs/api
Coverage reporting can be found in ./docs/coverage

## LICENSE INFORMATION
 
Please see the LICENSE file included in this distribution.

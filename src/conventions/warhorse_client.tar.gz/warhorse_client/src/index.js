/**
 * @file index.js
 * @description Client index.
 * @license See LICENSE file included in this distribution.
 */

// Imports

// Exports
module.exports = function() {
    "use strict";
    console.log("Warhorse Default Configuration: Client");
};

/**
 * @file index.js
 * @description Module index.
 * @license See LICENSE file included in this distribution.
 */

// Imports

// Exports
module.exports = function() {
    "use strict";
    console.log("Warhorse Default Configuration: Module");
};

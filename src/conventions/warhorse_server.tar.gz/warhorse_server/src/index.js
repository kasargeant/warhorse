/**
 * @file index.js
 * @description Server index.
 * @license See LICENSE file included in this distribution.
 */

// Imports

// Exports
module.exports = function() {
    "use strict";
    console.log("Warhorse Default Configuration: Server");
};